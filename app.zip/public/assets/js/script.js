// Referências dos elementos da página
const formulario = document.getElementById("cep-form");
const campoCep = document.getElementById("cep");
const mensagem = document.getElementById("mensagem");
const resultado = document.getElementById("resultado");

// Dispara a consulta quando o usuário pressiona Enter
formulario.addEventListener("submit", async function (evento) {
  evento.preventDefault();

  // Oculta resultados de consultas anteriores
  resultado.hidden = true;

  const cep = campoCep.value.trim();

  // Valida o formato: 8 dígitos, com ou sem hífen após o quinto
  if (!/^\d{5}-?\d{3}$/.test(cep)) {
    mensagem.textContent = "CEP inválido. Digite 12328070 ou 12328-070.";
    return;
  }

  mensagem.textContent = "Consultando...";
  campoCep.disabled = true;

  try {
    const cepLimpo = cep.replace("-", "");
    const resposta = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);

    if (!resposta.ok) {
      mensagem.textContent = `Erro do serviço: ${resposta.status} ${resposta.statusText}`;
      return;
    }

    const dados = await resposta.json();

    if (dados.erro) {
      mensagem.textContent = "CEP não encontrado.";
      return;
    }

    document.getElementById("valor-cep").textContent = dados.cep;
    document.getElementById("valor-logradouro").textContent = dados.logradouro || "Não informado";
    document.getElementById("valor-bairro").textContent = dados.bairro || "Não informado";
    document.getElementById("valor-cidade").textContent = dados.localidade;
    document.getElementById("valor-uf").textContent = dados.uf;
    document.getElementById("valor-ibge").textContent = dados.ibge;

    mensagem.textContent = "Resposta do ViaCEP:";
    resultado.hidden = false;
  } catch (erro) {
    mensagem.textContent = "Falha de conexão. Verifique sua internet e tente novamente.";
  } finally {
    campoCep.disabled = false;
    campoCep.focus();
  }
});
